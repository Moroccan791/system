In 2019 I created this typeface purely as a passion project for use in my own design work. I had been fascinated with the world of type design for some time and wanted to dive into it myself. It made some appearances on YouTube banners and also on the Album cover for the Warmer Heights Remix of Dust and Light’s “I Won’t Be Held Down.” Eventually I plucked up the courage to take the vector files through to a usable font using FontForge. Feel free to download it and use it in your own personal or commercial projects.

https://www.behance.net/robertduthie




